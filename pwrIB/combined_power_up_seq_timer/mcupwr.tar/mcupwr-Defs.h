//========================================================================
// ATMega128 MCU Powerboard Definitions Header File
//========================================================================
//
// Author: Matheus Ogleari and Sean Clark
//
// Description: This header file contains a series of helpful MACROS that
// greatly facilitate programming of the ATMega128 microcontroller. These
// definitiosn come directly from the datasheet

#ifndef MCUPWR_DEFS_H
#define MCUPWR_DEFS_H

//------------------------------------------------------------------------
// Include C libraries and AVR header libraries
//------------------------------------------------------------------------

#include <avr/io.h>
#include <avr/interrupt.h>
#include <avr/eeprom.h>
#include <avr/pgmspace.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <inttypes.h>
#include <util/delay.h>
#include "uart.h"

//------------------------------------------------------------------------
// Defines some useful values for coding
//------------------------------------------------------------------------

#define CLK             16000000
#define MCU_NOT_ON_FIRE 1

//------------------------------------------------------------------------
// Functions for bit twiddling
//------------------------------------------------------------------------

#define READ( U, N ) ( ( U ) >> ( N ) & 1u )
#define SET( U, N ) ( ( void )( ( U ) |= 1u << ( N ) ) )
#define CLR( U, N ) ( ( void )( ( U ) &= ~( 1u << ( N ) ) ) )

//------------------------------------------------------------------------
// Defines Register and I/O Component Behaviors
//------------------------------------------------------------------------

#define SET_GLOBAL_INTERRUPT_ENABLE sei()

// header commands received in a packet
#define COMPONENT_ON      0x00
#define COMPONENT_OFF     0x01
#define POWER_CYCLE       0x02
#define TORQ_CTRL         0x03
#define GET_TELEMETRY     0x04
#define FORCE_ON          0x05

// component names
#define SPECTROMETER      0x00
#define STAR_TRACKER      0x01
#define FC_5V             0x02
#define FC_3_3V           0x03
#define GPS_1             0x04
#define GPS_2             0x05
#define CDH_IB            0x06
#define HEATER_1          0x07
#define HEATER_2          0x08
#define CMG               0x09
#define SUN_SENSOR        0x0a
#define RADIO_1           0x0b
#define RADIO_2           0x0c
#define MAESTRO           0x0d
#define MAGNETOM          0x0e
#define FOG_15V           0x0f
#define FOG_5V            0x10
#define TORQUER_1         0x11
#define TORQUER_2         0x12
#define TORQUER_3         0x13
#define BATTERY_1         0x14
#define BATTERY_2         0x15
#define SOLAR_FULL        0x16
#define SOLAR_1           0x17
#define SOLAR_2           0x18
#define SOLAR_3           0x19
#define SOLAR_4           0x1a
#define SOLAR_5           0x1b
#define SOLAR_6           0x1c
#define SOLAR_7           0x1d
#define SOLAR_8           0x1e
#define SOLAR_9           0x1f
#define SOLAR_10          0x20
#define SOLAR_11          0x21
#define SOLAR_12          0x22
#define POWER_BOARD       0x23

// switch enables
#define SW_EN1  0x01
#define SW_EN2  0x02
#define SW_EN3  0x03
#define SW_EN4  0x04
#define SW_EN5  0x05
#define SW_EN6  0x06
#define SW_EN7  0x07
#define SW_EN8  0x08
#define SW_EN9  0x09
#define SW_EN10 0x0a
#define SW_EN11 0x0b
#define SW_EN12 0x0c
#define SW_EN13 0x0d
#define SW_EN14 0x0e
#define SW_EN15 0x0f
#define SW_EN16 0x10

#define SW_OFF 0
#define SW_ON  1

// TODO: Power telemetry packet types

// SVIT definitions
#define SVIT_SZ    35
#define NAME_SZ    8
#define MUX0       0
#define MUX1       1
#define MUX2       2
#define MUX_NULL   3

#define NUM_SAMPLES 7

#define BUFFER_SIZE 255

//------------------------------------------------------------------------
// Defines Some Enums and Structs
//------------------------------------------------------------------------

// 10-byte Packet type used for communication between MCU and FC
typedef struct Packet
{
  uint8_t   Fend0;
  uint8_t   Source_Dest;
  uint8_t   Data;
  uint16_t  crc;
  uint8_t  Fend1;
} Packet_t;

typedef struct SVIT
{
  uint8_t  name;

  uint8_t  switch_num;
  uint8_t  switch_state; // is the switch on or off?

  uint8_t  V_mux_num;              // which analog mux does this component belong to?
  uint8_t  V_mux_sel;              // mux select bits for choosing this component
  uint8_t  V_upper_limit;
  uint16_t V_samples[NUM_SAMPLES]; // previous 7 samples used to construct median value
  uint8_t  V_sample_index;

  uint8_t  I_mux_num;
  uint8_t  I_mux_sel;
  uint8_t  I_upper_limit;
  uint16_t I_samples[NUM_SAMPLES];
  uint8_t  I_sample_index;

  uint8_t  T_mux_num;
  uint8_t  T_mux_sel;
  uint8_t  T_upper_limit;
  uint16_t T_samples[NUM_SAMPLES];
  uint8_t  T_sample_index;
} SVIT_t;

SVIT_t svit[SVIT_SZ];

// State Machine for debouncing button presses
enum DebounceState
{
  NO_PUSH,
  MAYBE,
  PUSHED,
  MAY_REL
};

//------------------------------------------------------------------------
// Defines Some Functions 
//------------------------------------------------------------------------

void read_VIT( void );
void switch_on( uint8_t switch_num );
void switch_off( uint8_t switch_num );
void torquer_on( uint8_t torquer_num );
void torquer_off( uint8_t torquer_num );

#endif
