/*
 * Violet Satellite Power Board MCU
 *
 * Matheus Ogleari, Sean Clark
 * Spring 2012
 */

#include "mcupwr-Defs.h"
#include "vcp_library.h"
#include "uart.h"

// UART file descriptor for debugging purposes
FILE uart_str = FDEV_SETUP_STREAM(uart_putchar, uart_getchar, _FDEV_SETUP_RW);

volatile uint8_t timer0_counter;

uint8_t* tel_packet;
volatile uint16_t tel_packet_size;
volatile uint8_t tel_packet_index;

vcp_ptrbuffer* uart0_vcp_buff;
vcp_ptrbuffer* uart1_vcp_buff;

uint8_t* uart0_message_buff;
uint8_t* uart1_message_buff;

uint8_t rx_byte;

uint8_t num_bytes = 0;

inline void tx_put_byte()
{
  if(tel_packet_index < tel_packet_size) {
    UDR1 = tel_packet[tel_packet_index++];
	//fprintf(stdout, "Transmitting byte: %d\n", tel_packet[tel_packet_index-1]);
  }
}

inline void receive_message(uint8_t* message, uint8_t message_size)
{
  for(int i = 0; i < message_size; i++)
    fprintf(stdout, "received message byte: %d\n", message[i]);
}

ISR(TIMER0_COMP_vect)
{
  if(timer0_counter > 0)
    --timer0_counter;
}

ISR(USART1_TX_vect)
{
  tx_put_byte();
}

ISR(USART1_RX_vect)
{
  uint8_t status;

  rx_byte = UDR1;
  num_bytes++;

  status = Receive_VCP_byte(uart1_vcp_buff, rx_byte);

  if(status == VCP_TERM)
  {
    //fprintf(stdout, "asdf\n");
    receive_message(uart1_vcp_buff->message, uart1_vcp_buff->index);
    vcpptr_init(uart1_vcp_buff, uart1_message_buff, BUFFER_SIZE);
  }

  //fprintf(stdout, "Receive_VCP_byte status: %d\n", status);
}

void set_component(uint8_t svit_index, uint8_t name, uint8_t switch_num, uint8_t switch_state, uint8_t V_mux_num, uint8_t V_mux_sel, uint8_t V_upper_limit, uint8_t I_mux_num, uint8_t I_mux_sel, uint8_t I_upper_limit, uint8_t T_mux_num, uint8_t T_mux_sel, uint8_t T_upper_limit)
{
  svit[svit_index].name = name;
  svit[svit_index].switch_num = switch_num;
  svit[svit_index].switch_state = switch_state;

  svit[svit_index].V_mux_num = V_mux_num;
  svit[svit_index].V_mux_sel = V_mux_sel;
  svit[svit_index].V_upper_limit = V_upper_limit;
  svit[svit_index].V_sample_index = 0;

  svit[svit_index].I_mux_num = I_mux_num;
  svit[svit_index].I_mux_sel = I_mux_sel;
  svit[svit_index].I_upper_limit = I_upper_limit;
  svit[svit_index].I_sample_index = 0;

  svit[svit_index].T_mux_num = T_mux_num;
  svit[svit_index].T_mux_sel = T_mux_sel;
  svit[svit_index].T_upper_limit = T_upper_limit;
  svit[svit_index].T_sample_index = 0;
}

void initialize_svit(void)
{

  int svit_index = 0;

}

void initialize(void)
{
  /*
   * pin initialization
   */

  DDRA  = 0b11111111;
  PORTA = 0b00000111;

  DDRB  = 0b11111111;
  PORTB = 0b11100000;

  DDRC  = 0b11111111;
  PORTC = 0b11111111;

  DDRD  = 0b11111011;
  PORTD = 0b11110000;

  DDRE  = 0b11111110;
  PORTE = 0b00000000;

  DDRF  = 0b11110000;
  PORTF = 0b00000000;

  DDRG  = 0b00011111;
  PORTG = 0b00000100;

  /*
   * timer 0
   *
   * used for transmitting telemetry packet at 1 Hz
   *
   * mode = clear on match
   * prescalar = 1024
   * compare value = 124
   * compare match interrupt freq = (16 MHz / 1024 / 125) = 125 Hz = 8 ms
   * use timer0_counter to get 125 / 125 = 1 Hz
   */

  // enable clear on match interrupt
  TIMSK = (1 << OCIE0);
  OCR0 = 124;

  // enable clear on match mode, set prescalar to 1024
  TCCR0 = (1 << WGM01) | (1 << WGM00) | (1 << CS02) | (1 << CS01) | (1 << CS00);

  timer0_counter = 124;

  /*
   * communication structures
   */

  uart_init();

  // for use in debugging
  stdout = stdin = stderr = &uart_str;

  tel_packet = (uint8_t*) malloc(20);
  tel_packet_size = 0;
  tel_packet_index = 0;

  uart0_vcp_buff = (vcp_ptrbuffer*) malloc(sizeof(vcp_ptrbuffer));
  uart1_vcp_buff = (vcp_ptrbuffer*) malloc(sizeof(vcp_ptrbuffer));

  uart0_message_buff = (uint8_t*) malloc(BUFFER_SIZE);
  uart1_message_buff = (uint8_t*) malloc(BUFFER_SIZE);

  vcpptr_init(uart0_vcp_buff, uart0_message_buff, BUFFER_SIZE);
  vcpptr_init(uart1_vcp_buff, uart1_message_buff, BUFFER_SIZE);

  /*
   * svit
   */

  for(int i = 0; i < 32; i++)
  {
    // V
    svit[i].switch_num = i % 16;
    svit[i].switch_state = 1;

    svit[i].V_mux_num = (i % 3) == 0 ? MUX0 :
                        (i % 3) == 1 ? MUX1 :
                                       MUX2;

    svit[i].V_mux_sel = i % 8;

    svit[i].V_sample_index = 0;
    svit[i].V_upper_limit = 200;

    // I
    svit[i].I_mux_num = (i % 3) == 0 ? MUX0 :
                        (i % 3) == 1 ? MUX1 :
                                       MUX2;

    svit[i].I_mux_sel = i % 8;

    svit[i].I_sample_index = 0;
    svit[i].I_upper_limit = 200;

    // T
    svit[i].T_mux_num = (i % 3) == 0 ? MUX0 :
                        (i % 3) == 1 ? MUX1 :
                                       MUX2;

    svit[i].T_mux_sel = i % 8;

    svit[i].T_sample_index = 0;
    svit[i].T_upper_limit = 200;
  }

  /* 
   * ADC
   *
   * Vref = AVCC = 5 V
   * ADC clock = 16 MHz / 128 = 125 kHz
   */

  // set Vref to AVCC, left-adjust result into ADCH
  ADMUX = (1 << ADLAR) | (1 << REFS0);

  // enable ADC and set ADC division factor to 128
  ADCSRA = (1 << ADEN) | (1 << ADPS2) | (1 << ADPS1) | (1 << ADPS0);

  // rev up those interrupts
  sei();
}

void transmit_packet()
{
  uint8_t* source_data = NULL;
  uint16_t source_size = 10;

  uint8_t* dest_data = NULL;
  uint16_t* dest_size = NULL;

  uint8_t source_VCP_address = 0x00;

  uint8_t VCP_tx_status;

  uint16_t i;

  source_data = (uint8_t*) malloc(source_size);
  dest_data = (uint8_t*) malloc(20);
  dest_size = (uint16_t*) malloc(sizeof(uint16_t));

  if(source_data == NULL || tel_packet == NULL || dest_size == NULL)
    fprintf(stdout, "You dun goofed\n");

  for(i = 0; i < 10; i ++)
    source_data[i] = i;

/*
  // header
  source_data[0] = 0x00;

  // on/off state
  for(i = 1; i < SVIT_SZ + 1; i++)
  {
    source_data[i] = svit[i].switch_state;
  }

  // voltage
  for(i = SVIT_SZ + 1; i < SVIT_SZ + 1 + SVIT_SZ; i++)
  {
    source_data[i] = svit[i%SVIT_SZ].V_samples[0];
  }

  // current
  for(i = SVIT_SZ + 1 + SVIT_SZ; i < SVIT_SZ + 1 + SVIT_SZ + SVIT_SZ; i++)
  {
    source_data[i] = svit[i%SVIT_SZ].I_samples[0];
  }

  // temperature
  for(i = SVIT_SZ + 1 + SVIT_SZ + SVIT_SZ; i < SVIT_SZ + 1 + SVIT_SZ + SVIT_SZ + SVIT_SZ; i++)
  {
    source_data[i] = svit[i%SVIT_SZ].T_samples[0];
  }
  */

  // create VCP frame in the peripheral transmit buffer
  VCP_tx_status = Create_VCP_frame(
    dest_data,
    dest_size,
    source_VCP_address,
    source_data,
    source_size);

  fprintf(stdout, "VCP_tx_status: %d\n", VCP_tx_status);
  fprintf(stdout, "dest_size: %d\n", *dest_size);

  // VCP frame creation was successful
  if(VCP_tx_status == VCP_TERM)
  {
    tel_packet_size = *dest_size;

	if(dest_data == NULL)
	 fprintf(stdout, "Consequences...\n");

	//for(i = 0; i < tel_packet_size; i++)
	  //fprintf(stdout, "Byte from Create_VCP_frame: %d\n", dest_data[i]);

	memcpy(tel_packet, dest_data, tel_packet_size);

	//for(i = 0; i < tel_packet_size; i ++)
	  //tel_packet[i] = dest_data[i];


	for(i = 0; i < tel_packet_size; i++)
	  fprintf(stdout, "Byte to transmit: %d\n", tel_packet[i]);

    tel_packet_index = 0;

    //if(UCSR1A && (1 << UDRE))
     // tx_put_byte();
  }

  free(source_data);
  //free(dest_data);
  free(dest_size);
}

int main(void)
{
  initialize();
  fprintf(stdout, "\nuart initialized\n");

  while(1)
  {
    if(timer0_counter == 0) {
      timer0_counter = 124;
	  //fprintf(stdout, "Transmitting packet\n");
      transmit_packet();
    }

    //read_VIT();
  }
}
