//=======================================================================
// Voltage, current, temperature measurements
//=======================================================================

#include "mcupwr-Defs.h"

void set_mux_sel( uint8_t mux_num, uint8_t mux_sel )
{
  switch( mux_num )
  {
    case MUX0:
      READ( mux_sel, 4 ) ? SET( PORTA, 7 ) : CLR( PORTA, 7 );
      READ( mux_sel, 3 ) ? SET( PORTA, 6 ) : CLR( PORTA, 6 );
      READ( mux_sel, 2 ) ? SET( PORTA, 5 ) : CLR( PORTA, 5 );
      READ( mux_sel, 1 ) ? SET( PORTA, 4 ) : CLR( PORTA, 4 );
      READ( mux_sel, 0 ) ? SET( PORTA, 3 ) : CLR( PORTA, 3 );

      break;

    case MUX1:
      READ( mux_sel, 4 ) ? SET( PORTB, 0 ) : CLR( PORTB, 0 );
      READ( mux_sel, 3 ) ? SET( PORTB, 1 ) : CLR( PORTB, 1 );
      READ( mux_sel, 2 ) ? SET( PORTB, 2 ) : CLR( PORTB, 2 );
      READ( mux_sel, 1 ) ? SET( PORTB, 3 ) : CLR( PORTB, 3 );
      READ( mux_sel, 0 ) ? SET( PORTB, 4 ) : CLR( PORTB, 4 );

      break;

    case MUX2:
      READ( mux_sel, 4 ) ? SET( PORTE, 3 ) : CLR( PORTE, 3 );
      READ( mux_sel, 3 ) ? SET( PORTE, 4 ) : CLR( PORTE, 4 );
      READ( mux_sel, 2 ) ? SET( PORTE, 5 ) : CLR( PORTE, 5 );
      READ( mux_sel, 1 ) ? SET( PORTE, 6 ) : CLR( PORTE, 6 );
      READ( mux_sel, 0 ) ? SET( PORTE, 7 ) : CLR( PORTE, 7 );

      break;

    default:
      break;
  }
}


void torquer_off( uint8_t torquer_num )
{
  switch( torquer_num )
  {
    case 1:
      CLR( PORTC, 0 );
      break;

    // According to diagram, this pin is active low
    case 2:
      SET( PORTG, 1 );
      break;
    
    // According to the diagram, this pin is active low
    case 3:
      SET( PORTG, 0 );
      break;

    case 4:
      CLR( PORTD, 0 );
      break;

    case 5:
      CLR( PORTG, 3 );
      break;

    case 6:
      CLR( PORTG, 4 );
      break;

    default:
      break;
  }  
}

void torquer_on( uint8_t torquer_num )
{
  switch( torquer_num )
  {
    case 1:
      SET( PORTC, 0 );
      break;

    // According to diagram, this pin is active low
    case 2:
      CLR( PORTG, 1 );
      break;
    
    // According to the diagram, this pin is active low
    case 3:
      CLR( PORTG, 0 );
      break;

    case 4:
      SET( PORTD, 0 );
      break;

    case 5:
      SET( PORTG, 3 );
      break;

    case 6:
      SET( PORTG, 4 );
      break;

    default:
      break;
  }
}

void switch_on( uint8_t switch_num )
{
  switch ( switch_num )
  {
    case 1:
      SET( PORTA, 0 );
      break;

    case 2:
      SET( PORTA, 1 );
      break;

    case 3:
      SET( PORTA, 2 );
      break;

    case 4:
      SET( PORTB, 5 );
      break;

    case 5:
      SET( PORTB, 6 );
      break;

    case 6:
      SET( PORTB, 7 );
      break;

    case 7:
      SET( PORTD, 4 );
      break;

    case 8:
      SET( PORTD, 5 );
      break;

    case 9:
      SET( PORTG, 2 );
      break;

    case 10: 
      SET( PORTC, 7 );
      break;

    case 11:
      SET( PORTC, 6 );
      break;

    case 12:
      SET( PORTC, 5 );
      break;

    case 13:
      SET( PORTC, 4 );
      break;

    case 14:
      SET( PORTC, 3 );
      break;

    case 15:
      SET( PORTC, 2 );
      break;

    case 16:
      SET( PORTC, 1 );
      break;

    default:
      break;
  }
}

void switch_off( uint8_t switch_num )
{
  switch ( switch_num )
  {
    case 1:
      CLR( PORTA, 0 );
      break;

    case 2:
      CLR( PORTA, 1 );
      break;

    case 3:
      CLR( PORTA, 2 );
      break;

    case 4:
      CLR( PORTB, 5 );
      break;

    case 5:
      CLR( PORTB, 6 );
      break;

    case 6:
      CLR( PORTB, 7 );
      break;

    case 7:
      CLR( PORTD, 4 );
      break;

    case 8:
      CLR( PORTD, 5 );
      break;

    case 9:
      CLR( PORTG, 2 );
      break;

    case 10: 
      CLR( PORTC, 7 );
      break;

    case 11:
      CLR( PORTC, 6 );
      break;

    case 12:
      CLR( PORTC, 5 );
      break;

    case 13:
      CLR( PORTC, 4 );
      break;

    case 14:
      CLR( PORTC, 3 );
      break;

    case 15:
      CLR( PORTC, 2 );
      break;

    case 16:
      CLR( PORTC, 1 );
      break;

    default:
      break;
  }
}

uint8_t perform_ADC( uint8_t mux_num )
{
  // set Vref to AVCC and set the ADC channel to the correct pin ( mux_num )
  //ADMUX = (1 << REFS1) | ( 1 << REFS0 ) | mux_num;
  ADMUX = (1 << ADLAR) | ( 1 << REFS0 ) | mux_num;

  // signal ADC to start a new conversion
  ADCSRA |= ( 1 << ADSC );

  // when the conversion finishes, the ADSC bit is cleared
  // block while waiting for conversion to finish
  while( ADCSRA & ( 1 << ADSC ) );

  // when the conversion finishes, the result is stored in ADCL
  return ADCH;
}

void read_VIT( void )
{
  uint8_t mux_num;
  uint8_t mux_sel;

  uint8_t ADC_out;

  uint8_t sample_index;
  uint8_t i;

  SVIT_t* component;

  for( i = 0; i < SVIT_SZ; i++ )
  {
    //_delay_us(5);
    component = &svit[i];

    //-------------------------------------------------------------------
    // Measure voltage
    //-------------------------------------------------------------------

    mux_num = component->V_mux_num;
    mux_sel = component->V_mux_sel;

    set_mux_sel( mux_num, mux_sel );
    ADC_out = perform_ADC( mux_num );

    sample_index = component->V_sample_index;
    component->V_sample_index = ( sample_index + 1 ) % NUM_SAMPLES;
    component->V_samples[sample_index] = ADC_out;

    if ( ADC_out > component->V_upper_limit ) {
	  //fprintf(stdout, "switch for component %d turned off\n", i);
      switch_off( component->switch_num );
    }

	//fprintf(stdout, "ADC_out component %d = %d\n", i, ADC_out);

    //-------------------------------------------------------------------
    // Measure current
    //-------------------------------------------------------------------

    mux_num = component->I_mux_num;
    mux_sel = component->I_mux_sel;

    set_mux_sel( mux_num, mux_sel );
    ADC_out = perform_ADC( mux_num );

    sample_index = component->I_sample_index;
    component->I_sample_index = ( sample_index + 1 ) % NUM_SAMPLES;
    component->I_samples[sample_index] = ADC_out;

    if ( ADC_out > component->I_upper_limit )
      switch_off( component->switch_num );

    //-------------------------------------------------------------------
    // Measure temperature
    //-------------------------------------------------------------------

    mux_num = component->T_mux_num;

    if( mux_num != MUX_NULL )
    {
      mux_sel = component->T_mux_sel;

      set_mux_sel( mux_num, mux_sel );
      ADC_out = perform_ADC( mux_num );

      sample_index = component->T_sample_index;
      component->T_sample_index = ( sample_index + 1 ) % NUM_SAMPLES;
      component->T_samples[sample_index] = ADC_out;
      if ( ADC_out > component->T_upper_limit )
        switch_off( component->switch_num );
    }
  }
}
