#ifndef main_h
#define main_h

#include <avr/interrupt.h>

#define CLOCK_SPEED 14745600UL // 16 MHz

void send(char *str, int len);
void initialize();
void retrieve_gps_data();

#endif
