﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmComm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.SerialPort = New System.IO.Ports.SerialPort(Me.components)
        Me.PortStatus = New System.Windows.Forms.Label()
        Me.Port_Open_Close = New System.Windows.Forms.Button()
        Me.COMPortsBox = New System.Windows.Forms.ComboBox()
        Me.ComPortLabel = New System.Windows.Forms.Label()
        Me.ClearButton = New System.Windows.Forms.Button()
        Me.ReceivedLabel = New System.Windows.Forms.Label()
        Me.Received = New System.Windows.Forms.TextBox()
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip()
        Me.FileToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.RefreshPortsListToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.AboutToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ExitToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.btnSaveAs = New System.Windows.Forms.Button()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.textPosX = New System.Windows.Forms.TextBox()
        Me.textPosY = New System.Windows.Forms.TextBox()
        Me.textPosZ = New System.Windows.Forms.TextBox()
        Me.textVelX = New System.Windows.Forms.TextBox()
        Me.textVelY = New System.Windows.Forms.TextBox()
        Me.textVelZ = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.textMinute = New System.Windows.Forms.TextBox()
        Me.textHour = New System.Windows.Forms.TextBox()
        Me.textDay = New System.Windows.Forms.TextBox()
        Me.textMonth = New System.Windows.Forms.TextBox()
        Me.textYear = New System.Windows.Forms.TextBox()
        Me.textSecond = New System.Windows.Forms.TextBox()
        Me.textGPSWeek = New System.Windows.Forms.TextBox()
        Me.textGPSSec = New System.Windows.Forms.TextBox()
        Me.textDoppClk = New System.Windows.Forms.TextBox()
        Me.textTimeType = New System.Windows.Forms.TextBox()
        Me.textTrackType = New System.Windows.Forms.TextBox()
        Me.textNavMode = New System.Windows.Forms.TextBox()
        Me.textGdop = New System.Windows.Forms.TextBox()
        Me.textPdop = New System.Windows.Forms.TextBox()
        Me.textVdop = New System.Windows.Forms.TextBox()
        Me.textNumsats = New System.Windows.Forms.TextBox()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.Label19 = New System.Windows.Forms.Label()
        Me.Label20 = New System.Windows.Forms.Label()
        Me.Label21 = New System.Windows.Forms.Label()
        Me.textAnalog1 = New System.Windows.Forms.TextBox()
        Me.textAnalog2 = New System.Windows.Forms.TextBox()
        Me.textAnalog3 = New System.Windows.Forms.TextBox()
        Me.Label22 = New System.Windows.Forms.Label()
        Me.Label23 = New System.Windows.Forms.Label()
        Me.Label24 = New System.Windows.Forms.Label()
        Me.Label25 = New System.Windows.Forms.Label()
        Me.Label26 = New System.Windows.Forms.Label()
        Me.Label27 = New System.Windows.Forms.Label()
        Me.textAlt = New System.Windows.Forms.TextBox()
        Me.textLon = New System.Windows.Forms.TextBox()
        Me.textLat = New System.Windows.Forms.TextBox()
        Me.MenuStrip1.SuspendLayout()
        Me.SuspendLayout()
        '
        'SerialPort
        '
        Me.SerialPort.BaudRate = 115200
        Me.SerialPort.PortName = "COM9"
        '
        'PortStatus
        '
        Me.PortStatus.AutoSize = True
        Me.PortStatus.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.PortStatus.Location = New System.Drawing.Point(103, 126)
        Me.PortStatus.Name = "PortStatus"
        Me.PortStatus.Size = New System.Drawing.Size(78, 16)
        Me.PortStatus.TabIndex = 23
        Me.PortStatus.Text = "Port Closed"
        '
        'Port_Open_Close
        '
        Me.Port_Open_Close.Location = New System.Drawing.Point(100, 58)
        Me.Port_Open_Close.Name = "Port_Open_Close"
        Me.Port_Open_Close.Size = New System.Drawing.Size(84, 23)
        Me.Port_Open_Close.TabIndex = 24
        Me.Port_Open_Close.TabStop = False
        Me.Port_Open_Close.Text = "Open Port"
        Me.Port_Open_Close.UseVisualStyleBackColor = True
        '
        'COMPortsBox
        '
        Me.COMPortsBox.FormattingEnabled = True
        Me.COMPortsBox.Location = New System.Drawing.Point(100, 92)
        Me.COMPortsBox.Name = "COMPortsBox"
        Me.COMPortsBox.Size = New System.Drawing.Size(84, 21)
        Me.COMPortsBox.TabIndex = 25
        Me.COMPortsBox.TabStop = False
        '
        'ComPortLabel
        '
        Me.ComPortLabel.AutoSize = True
        Me.ComPortLabel.Location = New System.Drawing.Point(40, 95)
        Me.ComPortLabel.Name = "ComPortLabel"
        Me.ComPortLabel.Size = New System.Drawing.Size(53, 13)
        Me.ComPortLabel.TabIndex = 26
        Me.ComPortLabel.Text = "COM Port"
        '
        'ClearButton
        '
        Me.ClearButton.Location = New System.Drawing.Point(40, 460)
        Me.ClearButton.Name = "ClearButton"
        Me.ClearButton.Size = New System.Drawing.Size(75, 23)
        Me.ClearButton.TabIndex = 32
        Me.ClearButton.TabStop = False
        Me.ClearButton.Text = "Reset"
        Me.ClearButton.UseVisualStyleBackColor = True
        '
        'ReceivedLabel
        '
        Me.ReceivedLabel.AutoSize = True
        Me.ReceivedLabel.Location = New System.Drawing.Point(40, 183)
        Me.ReceivedLabel.Name = "ReceivedLabel"
        Me.ReceivedLabel.Size = New System.Drawing.Size(53, 13)
        Me.ReceivedLabel.TabIndex = 31
        Me.ReceivedLabel.Text = "Received"
        '
        'Received
        '
        Me.Received.Font = New System.Drawing.Font("Courier New", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Received.Location = New System.Drawing.Point(12, 210)
        Me.Received.Multiline = True
        Me.Received.Name = "Received"
        Me.Received.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.Received.Size = New System.Drawing.Size(350, 230)
        Me.Received.TabIndex = 28
        Me.Received.TabStop = False
        '
        'MenuStrip1
        '
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.FileToolStripMenuItem})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Size = New System.Drawing.Size(878, 24)
        Me.MenuStrip1.TabIndex = 72
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'FileToolStripMenuItem
        '
        Me.FileToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.RefreshPortsListToolStripMenuItem, Me.AboutToolStripMenuItem, Me.ExitToolStripMenuItem1})
        Me.FileToolStripMenuItem.Name = "FileToolStripMenuItem"
        Me.FileToolStripMenuItem.Size = New System.Drawing.Size(38, 20)
        Me.FileToolStripMenuItem.Text = "&GUI"
        '
        'RefreshPortsListToolStripMenuItem
        '
        Me.RefreshPortsListToolStripMenuItem.Name = "RefreshPortsListToolStripMenuItem"
        Me.RefreshPortsListToolStripMenuItem.Size = New System.Drawing.Size(161, 22)
        Me.RefreshPortsListToolStripMenuItem.Text = "Refresh Ports list"
        '
        'AboutToolStripMenuItem
        '
        Me.AboutToolStripMenuItem.Name = "AboutToolStripMenuItem"
        Me.AboutToolStripMenuItem.Size = New System.Drawing.Size(161, 22)
        Me.AboutToolStripMenuItem.Text = "A&bout"
        '
        'ExitToolStripMenuItem1
        '
        Me.ExitToolStripMenuItem1.Name = "ExitToolStripMenuItem1"
        Me.ExitToolStripMenuItem1.Size = New System.Drawing.Size(161, 22)
        Me.ExitToolStripMenuItem1.Text = "E&xit"
        '
        'btnSaveAs
        '
        Me.btnSaveAs.Location = New System.Drawing.Point(137, 460)
        Me.btnSaveAs.Name = "btnSaveAs"
        Me.btnSaveAs.Size = New System.Drawing.Size(103, 23)
        Me.btnSaveAs.TabIndex = 77
        Me.btnSaveAs.TabStop = False
        Me.btnSaveAs.Text = "Stop and Save As"
        Me.btnSaveAs.UseVisualStyleBackColor = True
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(430, 144)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(44, 13)
        Me.Label1.TabIndex = 78
        Me.Label1.Text = "Position"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(430, 174)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(44, 13)
        Me.Label2.TabIndex = 79
        Me.Label2.Text = "Velocity"
        '
        'textPosX
        '
        Me.textPosX.Location = New System.Drawing.Point(500, 140)
        Me.textPosX.Name = "textPosX"
        Me.textPosX.Size = New System.Drawing.Size(100, 20)
        Me.textPosX.TabIndex = 80
        '
        'textPosY
        '
        Me.textPosY.Location = New System.Drawing.Point(610, 140)
        Me.textPosY.Name = "textPosY"
        Me.textPosY.Size = New System.Drawing.Size(100, 20)
        Me.textPosY.TabIndex = 81
        '
        'textPosZ
        '
        Me.textPosZ.Location = New System.Drawing.Point(720, 140)
        Me.textPosZ.Name = "textPosZ"
        Me.textPosZ.Size = New System.Drawing.Size(100, 20)
        Me.textPosZ.TabIndex = 82
        '
        'textVelX
        '
        Me.textVelX.Location = New System.Drawing.Point(500, 170)
        Me.textVelX.Name = "textVelX"
        Me.textVelX.Size = New System.Drawing.Size(100, 20)
        Me.textVelX.TabIndex = 83
        '
        'textVelY
        '
        Me.textVelY.Location = New System.Drawing.Point(610, 170)
        Me.textVelY.Name = "textVelY"
        Me.textVelY.Size = New System.Drawing.Size(100, 20)
        Me.textVelY.TabIndex = 84
        '
        'textVelZ
        '
        Me.textVelZ.Location = New System.Drawing.Point(720, 170)
        Me.textVelZ.Name = "textVelZ"
        Me.textVelZ.Size = New System.Drawing.Size(100, 20)
        Me.textVelZ.TabIndex = 85
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(543, 113)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(14, 13)
        Me.Label3.TabIndex = 86
        Me.Label3.Text = "X"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(653, 113)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(14, 13)
        Me.Label4.TabIndex = 87
        Me.Label4.Text = "Y"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(763, 113)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(14, 13)
        Me.Label5.TabIndex = 88
        Me.Label5.Text = "Z"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(430, 364)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(44, 13)
        Me.Label6.TabIndex = 89
        Me.Label6.Text = "Second"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(430, 334)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(39, 13)
        Me.Label7.TabIndex = 90
        Me.Label7.Text = "Minute"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(430, 304)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(30, 13)
        Me.Label8.TabIndex = 91
        Me.Label8.Text = "Hour"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(430, 214)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(29, 13)
        Me.Label9.TabIndex = 92
        Me.Label9.Text = "Year"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(430, 244)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(37, 13)
        Me.Label10.TabIndex = 93
        Me.Label10.Text = "Month"
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Location = New System.Drawing.Point(430, 274)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(26, 13)
        Me.Label11.TabIndex = 94
        Me.Label11.Text = "Day"
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Location = New System.Drawing.Point(430, 424)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(58, 13)
        Me.Label12.TabIndex = 95
        Me.Label12.Text = "GPS week"
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Location = New System.Drawing.Point(430, 394)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(49, 13)
        Me.Label13.TabIndex = 96
        Me.Label13.Text = "GPS sec"
        '
        'textMinute
        '
        Me.textMinute.Location = New System.Drawing.Point(500, 330)
        Me.textMinute.Name = "textMinute"
        Me.textMinute.Size = New System.Drawing.Size(100, 20)
        Me.textMinute.TabIndex = 97
        '
        'textHour
        '
        Me.textHour.Location = New System.Drawing.Point(500, 300)
        Me.textHour.Name = "textHour"
        Me.textHour.Size = New System.Drawing.Size(100, 20)
        Me.textHour.TabIndex = 98
        '
        'textDay
        '
        Me.textDay.Location = New System.Drawing.Point(500, 270)
        Me.textDay.Name = "textDay"
        Me.textDay.Size = New System.Drawing.Size(100, 20)
        Me.textDay.TabIndex = 99
        '
        'textMonth
        '
        Me.textMonth.Location = New System.Drawing.Point(500, 240)
        Me.textMonth.Name = "textMonth"
        Me.textMonth.Size = New System.Drawing.Size(100, 20)
        Me.textMonth.TabIndex = 100
        '
        'textYear
        '
        Me.textYear.Location = New System.Drawing.Point(500, 210)
        Me.textYear.Name = "textYear"
        Me.textYear.Size = New System.Drawing.Size(100, 20)
        Me.textYear.TabIndex = 101
        '
        'textSecond
        '
        Me.textSecond.Location = New System.Drawing.Point(500, 360)
        Me.textSecond.Name = "textSecond"
        Me.textSecond.Size = New System.Drawing.Size(100, 20)
        Me.textSecond.TabIndex = 102
        '
        'textGPSWeek
        '
        Me.textGPSWeek.Location = New System.Drawing.Point(500, 420)
        Me.textGPSWeek.Name = "textGPSWeek"
        Me.textGPSWeek.Size = New System.Drawing.Size(100, 20)
        Me.textGPSWeek.TabIndex = 103
        '
        'textGPSSec
        '
        Me.textGPSSec.Location = New System.Drawing.Point(500, 390)
        Me.textGPSSec.Name = "textGPSSec"
        Me.textGPSSec.Size = New System.Drawing.Size(100, 20)
        Me.textGPSSec.TabIndex = 104
        '
        'textDoppClk
        '
        Me.textDoppClk.Location = New System.Drawing.Point(720, 390)
        Me.textDoppClk.Name = "textDoppClk"
        Me.textDoppClk.Size = New System.Drawing.Size(100, 20)
        Me.textDoppClk.TabIndex = 120
        '
        'textTimeType
        '
        Me.textTimeType.Location = New System.Drawing.Point(720, 420)
        Me.textTimeType.Name = "textTimeType"
        Me.textTimeType.Size = New System.Drawing.Size(100, 20)
        Me.textTimeType.TabIndex = 119
        '
        'textTrackType
        '
        Me.textTrackType.Location = New System.Drawing.Point(720, 360)
        Me.textTrackType.Name = "textTrackType"
        Me.textTrackType.Size = New System.Drawing.Size(100, 20)
        Me.textTrackType.TabIndex = 118
        '
        'textNavMode
        '
        Me.textNavMode.Location = New System.Drawing.Point(720, 210)
        Me.textNavMode.Name = "textNavMode"
        Me.textNavMode.Size = New System.Drawing.Size(100, 20)
        Me.textNavMode.TabIndex = 117
        '
        'textGdop
        '
        Me.textGdop.Location = New System.Drawing.Point(720, 240)
        Me.textGdop.Name = "textGdop"
        Me.textGdop.Size = New System.Drawing.Size(100, 20)
        Me.textGdop.TabIndex = 116
        '
        'textPdop
        '
        Me.textPdop.Location = New System.Drawing.Point(720, 270)
        Me.textPdop.Name = "textPdop"
        Me.textPdop.Size = New System.Drawing.Size(100, 20)
        Me.textPdop.TabIndex = 115
        '
        'textVdop
        '
        Me.textVdop.Location = New System.Drawing.Point(720, 300)
        Me.textVdop.Name = "textVdop"
        Me.textVdop.Size = New System.Drawing.Size(100, 20)
        Me.textVdop.TabIndex = 114
        '
        'textNumsats
        '
        Me.textNumsats.Location = New System.Drawing.Point(720, 330)
        Me.textNumsats.Name = "textNumsats"
        Me.textNumsats.Size = New System.Drawing.Size(100, 20)
        Me.textNumsats.TabIndex = 113
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Location = New System.Drawing.Point(650, 394)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(51, 13)
        Me.Label14.TabIndex = 112
        Me.Label14.Text = "Dopp Clk"
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Location = New System.Drawing.Point(650, 424)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(57, 13)
        Me.Label15.TabIndex = 111
        Me.Label15.Text = "Time Type"
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.Location = New System.Drawing.Point(650, 274)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(32, 13)
        Me.Label16.TabIndex = 110
        Me.Label16.Text = "Pdop"
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.Location = New System.Drawing.Point(650, 244)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(33, 13)
        Me.Label17.TabIndex = 109
        Me.Label17.Text = "Gdop"
        '
        'Label18
        '
        Me.Label18.AutoSize = True
        Me.Label18.Location = New System.Drawing.Point(650, 214)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(54, 13)
        Me.Label18.TabIndex = 108
        Me.Label18.Text = "NavMode"
        '
        'Label19
        '
        Me.Label19.AutoSize = True
        Me.Label19.Location = New System.Drawing.Point(650, 304)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(32, 13)
        Me.Label19.TabIndex = 107
        Me.Label19.Text = "Vdop"
        '
        'Label20
        '
        Me.Label20.AutoSize = True
        Me.Label20.Location = New System.Drawing.Point(650, 334)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(48, 13)
        Me.Label20.TabIndex = 106
        Me.Label20.Text = "Numsats"
        '
        'Label21
        '
        Me.Label21.AutoSize = True
        Me.Label21.Location = New System.Drawing.Point(650, 364)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(55, 13)
        Me.Label21.TabIndex = 105
        Me.Label21.Text = "Tracktype"
        '
        'textAnalog1
        '
        Me.textAnalog1.Location = New System.Drawing.Point(500, 60)
        Me.textAnalog1.Name = "textAnalog1"
        Me.textAnalog1.Size = New System.Drawing.Size(100, 20)
        Me.textAnalog1.TabIndex = 121
        '
        'textAnalog2
        '
        Me.textAnalog2.Location = New System.Drawing.Point(610, 60)
        Me.textAnalog2.Name = "textAnalog2"
        Me.textAnalog2.Size = New System.Drawing.Size(100, 20)
        Me.textAnalog2.TabIndex = 122
        '
        'textAnalog3
        '
        Me.textAnalog3.Location = New System.Drawing.Point(720, 60)
        Me.textAnalog3.Name = "textAnalog3"
        Me.textAnalog3.Size = New System.Drawing.Size(100, 20)
        Me.textAnalog3.TabIndex = 123
        '
        'Label22
        '
        Me.Label22.AutoSize = True
        Me.Label22.Location = New System.Drawing.Point(526, 41)
        Me.Label22.Name = "Label22"
        Me.Label22.Size = New System.Drawing.Size(49, 13)
        Me.Label22.TabIndex = 124
        Me.Label22.Text = "Analog 1"
        '
        'Label23
        '
        Me.Label23.AutoSize = True
        Me.Label23.Location = New System.Drawing.Point(636, 41)
        Me.Label23.Name = "Label23"
        Me.Label23.Size = New System.Drawing.Size(49, 13)
        Me.Label23.TabIndex = 125
        Me.Label23.Text = "Analog 2"
        '
        'Label24
        '
        Me.Label24.AutoSize = True
        Me.Label24.Location = New System.Drawing.Point(746, 41)
        Me.Label24.Name = "Label24"
        Me.Label24.Size = New System.Drawing.Size(49, 13)
        Me.Label24.TabIndex = 126
        Me.Label24.Text = "Analog 3"
        '
        'Label25
        '
        Me.Label25.AutoSize = True
        Me.Label25.Location = New System.Drawing.Point(749, 464)
        Me.Label25.Name = "Label25"
        Me.Label25.Size = New System.Drawing.Size(42, 13)
        Me.Label25.TabIndex = 132
        Me.Label25.Text = "Altitude"
        '
        'Label26
        '
        Me.Label26.AutoSize = True
        Me.Label26.Location = New System.Drawing.Point(633, 464)
        Me.Label26.Name = "Label26"
        Me.Label26.Size = New System.Drawing.Size(54, 13)
        Me.Label26.TabIndex = 131
        Me.Label26.Text = "Longitude"
        '
        'Label27
        '
        Me.Label27.AutoSize = True
        Me.Label27.Location = New System.Drawing.Point(528, 464)
        Me.Label27.Name = "Label27"
        Me.Label27.Size = New System.Drawing.Size(45, 13)
        Me.Label27.TabIndex = 130
        Me.Label27.Text = "Latitude"
        '
        'textAlt
        '
        Me.textAlt.Location = New System.Drawing.Point(720, 484)
        Me.textAlt.Name = "textAlt"
        Me.textAlt.Size = New System.Drawing.Size(100, 20)
        Me.textAlt.TabIndex = 129
        '
        'textLon
        '
        Me.textLon.Location = New System.Drawing.Point(610, 484)
        Me.textLon.Name = "textLon"
        Me.textLon.Size = New System.Drawing.Size(100, 20)
        Me.textLon.TabIndex = 128
        '
        'textLat
        '
        Me.textLat.Location = New System.Drawing.Point(500, 484)
        Me.textLat.Name = "textLat"
        Me.textLat.Size = New System.Drawing.Size(100, 20)
        Me.textLat.TabIndex = 127
        '
        'frmComm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(878, 516)
        Me.Controls.Add(Me.Label25)
        Me.Controls.Add(Me.Label26)
        Me.Controls.Add(Me.Label27)
        Me.Controls.Add(Me.textAlt)
        Me.Controls.Add(Me.textLon)
        Me.Controls.Add(Me.textLat)
        Me.Controls.Add(Me.Label24)
        Me.Controls.Add(Me.Label23)
        Me.Controls.Add(Me.Label22)
        Me.Controls.Add(Me.textAnalog3)
        Me.Controls.Add(Me.textAnalog2)
        Me.Controls.Add(Me.textAnalog1)
        Me.Controls.Add(Me.textDoppClk)
        Me.Controls.Add(Me.textTimeType)
        Me.Controls.Add(Me.textTrackType)
        Me.Controls.Add(Me.textNavMode)
        Me.Controls.Add(Me.textGdop)
        Me.Controls.Add(Me.textPdop)
        Me.Controls.Add(Me.textVdop)
        Me.Controls.Add(Me.textNumsats)
        Me.Controls.Add(Me.Label14)
        Me.Controls.Add(Me.Label15)
        Me.Controls.Add(Me.Label16)
        Me.Controls.Add(Me.Label17)
        Me.Controls.Add(Me.Label18)
        Me.Controls.Add(Me.Label19)
        Me.Controls.Add(Me.Label20)
        Me.Controls.Add(Me.Label21)
        Me.Controls.Add(Me.textGPSSec)
        Me.Controls.Add(Me.textGPSWeek)
        Me.Controls.Add(Me.textSecond)
        Me.Controls.Add(Me.textYear)
        Me.Controls.Add(Me.textMonth)
        Me.Controls.Add(Me.textDay)
        Me.Controls.Add(Me.textHour)
        Me.Controls.Add(Me.textMinute)
        Me.Controls.Add(Me.Label13)
        Me.Controls.Add(Me.Label12)
        Me.Controls.Add(Me.Label11)
        Me.Controls.Add(Me.Label10)
        Me.Controls.Add(Me.Label9)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.textVelZ)
        Me.Controls.Add(Me.textVelY)
        Me.Controls.Add(Me.textVelX)
        Me.Controls.Add(Me.textPosZ)
        Me.Controls.Add(Me.textPosY)
        Me.Controls.Add(Me.textPosX)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.btnSaveAs)
        Me.Controls.Add(Me.ClearButton)
        Me.Controls.Add(Me.ReceivedLabel)
        Me.Controls.Add(Me.Received)
        Me.Controls.Add(Me.ComPortLabel)
        Me.Controls.Add(Me.COMPortsBox)
        Me.Controls.Add(Me.Port_Open_Close)
        Me.Controls.Add(Me.PortStatus)
        Me.Controls.Add(Me.MenuStrip1)
        Me.MainMenuStrip = Me.MenuStrip1
        Me.Name = "frmComm"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.Manual
        Me.Text = "GPSTestGUI"
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents SerialPort As System.IO.Ports.SerialPort
    Friend WithEvents PortStatus As System.Windows.Forms.Label
    Friend WithEvents Port_Open_Close As System.Windows.Forms.Button
    Friend WithEvents COMPortsBox As System.Windows.Forms.ComboBox
    Friend WithEvents ComPortLabel As System.Windows.Forms.Label
    Friend WithEvents ClearButton As System.Windows.Forms.Button
    Friend WithEvents ReceivedLabel As System.Windows.Forms.Label
    Friend WithEvents Received As System.Windows.Forms.TextBox
    Friend WithEvents MenuStrip1 As System.Windows.Forms.MenuStrip
    Friend WithEvents FileToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ExitToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents AboutToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents RefreshPortsListToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents btnSaveAs As System.Windows.Forms.Button
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents textPosX As System.Windows.Forms.TextBox
    Friend WithEvents textPosY As System.Windows.Forms.TextBox
    Friend WithEvents textPosZ As System.Windows.Forms.TextBox
    Friend WithEvents textVelX As System.Windows.Forms.TextBox
    Friend WithEvents textVelY As System.Windows.Forms.TextBox
    Friend WithEvents textVelZ As System.Windows.Forms.TextBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents textMinute As System.Windows.Forms.TextBox
    Friend WithEvents textHour As System.Windows.Forms.TextBox
    Friend WithEvents textDay As System.Windows.Forms.TextBox
    Friend WithEvents textMonth As System.Windows.Forms.TextBox
    Friend WithEvents textYear As System.Windows.Forms.TextBox
    Friend WithEvents textSecond As System.Windows.Forms.TextBox
    Friend WithEvents textGPSWeek As System.Windows.Forms.TextBox
    Friend WithEvents textGPSSec As System.Windows.Forms.TextBox
    Friend WithEvents textDoppClk As System.Windows.Forms.TextBox
    Friend WithEvents textTimeType As System.Windows.Forms.TextBox
    Friend WithEvents textTrackType As System.Windows.Forms.TextBox
    Friend WithEvents textNavMode As System.Windows.Forms.TextBox
    Friend WithEvents textGdop As System.Windows.Forms.TextBox
    Friend WithEvents textPdop As System.Windows.Forms.TextBox
    Friend WithEvents textVdop As System.Windows.Forms.TextBox
    Friend WithEvents textNumsats As System.Windows.Forms.TextBox
    Friend WithEvents Label14 As System.Windows.Forms.Label
    Friend WithEvents Label15 As System.Windows.Forms.Label
    Friend WithEvents Label16 As System.Windows.Forms.Label
    Friend WithEvents Label17 As System.Windows.Forms.Label
    Friend WithEvents Label18 As System.Windows.Forms.Label
    Friend WithEvents Label19 As System.Windows.Forms.Label
    Friend WithEvents Label20 As System.Windows.Forms.Label
    Friend WithEvents Label21 As System.Windows.Forms.Label
    Friend WithEvents textAnalog1 As System.Windows.Forms.TextBox
    Friend WithEvents textAnalog2 As System.Windows.Forms.TextBox
    Friend WithEvents textAnalog3 As System.Windows.Forms.TextBox
    Friend WithEvents Label22 As System.Windows.Forms.Label
    Friend WithEvents Label23 As System.Windows.Forms.Label
    Friend WithEvents Label24 As System.Windows.Forms.Label
    Friend WithEvents Label25 As System.Windows.Forms.Label
    Friend WithEvents Label26 As System.Windows.Forms.Label
    Friend WithEvents Label27 As System.Windows.Forms.Label
    Friend WithEvents textAlt As System.Windows.Forms.TextBox
    Friend WithEvents textLon As System.Windows.Forms.TextBox
    Friend WithEvents textLat As System.Windows.Forms.TextBox
End Class
